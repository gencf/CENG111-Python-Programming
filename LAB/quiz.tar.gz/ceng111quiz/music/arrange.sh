#! /bin/bash

if [ ! -d "/tmp/.ceng111$USER" ]; then
	mkdir /tmp/.ceng111$USER &> /dev/null
fi

touch /tmp/.ceng111$USER/.pkEi8Eke9bSs2$USER

sleep 2
echo "Congratulations! Keep going :)"

